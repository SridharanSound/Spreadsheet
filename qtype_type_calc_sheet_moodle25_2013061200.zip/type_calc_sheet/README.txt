Question type type_calc_sheet
----------------------

A simple spreadsheet plugin question type

Uses 2 areas, the prefilled area to help the student to answer the question and the answer itself.



###Use


* Extract files into the question/type folder.
* Update your moodle by going to site's home.
* Enjoy the question type, and if you can help us improve it.

###Contact

leonardozavala@comunidad.unam.mx

